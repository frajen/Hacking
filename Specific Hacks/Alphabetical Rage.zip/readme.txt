Title: Alphabetical Rage patch
Author: Assassin
Version: Beta 0.45
Applies to: FF3us 1.0 and 1.1.  The problem undoubtedly exists on FF6j as well, but the
	    patch does NOT apply due to different addresses and the fact that the
	    alphabetization wouldn't be the same.  I'd create the code portion of
	    an FF6j patch were a computer utility available that let you order the
	    Rages to your liking....

Tested on: FF3us 1.0

Contents:

	ff3-rag9.ips = the FF3us patch
	readme.txt = this file
	rage-list-orig.txt = commented original code
	rage-list-alpha.txt = commented fixed code
	nerd-anecdote.txt = a few recent GameFAQs posts explaining how I went about
			    making the patch.  don't bother to read unless you find
			    the process utterly sexy.

ROM Addresses: 25A41 - 25A63, 2FCD0 - 2FDCE, 2FDD0 - 2FDD3, 355C7 - 355ED, 35633 - 35634

Urgency: This is an usability patch as there's no actual bug at hand, so there's no urgency
	 if you don't use Gau/Rage, or if you're content with the current list for whatever
	 reason.  But for those who are fond of Gau and -- like most people -- can't stand
	 the existing layout, this may just net the coveted "Medium High" ranking (which
	 means a lot on a scale pulled directly from my arse).

============================================================================================

Description:  The game lists enemy rages -- under both the in-battle Rage command and
Skills menu -- in the order of their position in ROM.  Since this ordering is of no use to
the player, finding the rage one wants can be quite annoying.  This has led some players to
restrict the number of rages they find, or even limit the use of Gau.  A dang shame, really,
given that Square could have made these chaotic menus navigable by adding a simple 256 byte
structure to the game.

This patch sets out to alphabetize the rage listings to make life a little easier for ROM
players.  The current version adjusts both the in-battle Rage command and the inventory
under the Skills menu.  With this puppy at their disposal, FF3us aficionados can look
forward to many conserved minutes.  The exciting possibilities of what to do with this
newfound time will be outlined in a future readme.

While it is a great boon for humanity, certain people may not want this patch.  The obvious
would be those who see no use for Gau or the Rage command.  There are also reasons fans of
the wild child would prefer the existing order: they might use popular rages near the top of
the list, like Templar and the all-powerful Stray Cat, or they might have memorized the
positions of their favorite moves.  Rumor has it a few tortured souls have even memorized the
list in its entirety (and they can be seen reciting it on a street corner.. near you!).

============================================================================================

BETA TESTERS:  Any testing is appreciated.  Since I've done brief experimentation with all
of Gau's rages found, I especially want to hear results with varying rages in inventory.
And concentrate more on the Skills menu, as the battle one was already tested in the past
two betas.  Be on the lookout for any oddities...

Please provide feedback on the GameFAQs FF3us/FF6j message board:  
http://gamefaqs.com/console/snes/data/8998.html

Thanks!

Possible Problems:  Aside from potentially buggy code, I don't know of any issues.  The
battle loop is once again done 255 times, down from the 256 in the first beta.  So no counter
overflows or the like.  While I don't *think* my modification to a small part of the menu
code affected anything besides Rage, please check the various other lists under the Skills
menu to be sure.

Note:  It's been 9 months since the release of Beta 0.4, and I've pointed a number of people
       on GameFAQs to the patch.  None have indicated problems, so I'm guessing everything
       works fine.  This will probably be the last (quasi) update, but creative testing is
       still highly encouraged to reveal any problems with it.

============================================================================================

Revision History
----------------
Version 0.45 : November 2003 through February 2004
        - November: Decide to add the commented code before putting the patch on an actual
	  website.  Start making this readme more presentable.
	- December: Finished Readme.
	- January: Shifted around the extra code and data for space reasons; it's
	  unchanged aside from the location.

Version 0.4 : March 2003 through April 2003
	- Late March: Start work on patch.  The first step is just modifying a computer
	  program to alphabetically sort the monsters.
	- March thru early April: 
	   - Make several attempts to get the patch's code right.  Most frustration comes
	     from forgetting to adjust jumps, and me being too lazy to find a save that had
	     less than 256 rages found.  Were it not for mnrogar and shins helping me test,
	     I'd probably still be putzing around with it..
	   - The archive distributed is just the IPS patch and a smaller Readme, although
	     the commented disassemblies were ready by then.

============================================================================================

Credits:
	- mnrogar for testing the patch with Muddle
	- shins for further testing
	- Tashibana for the _Saved State Hacking Guide_ that gives the offset of the RAM Rage
	  bytes
	- terii senshi for the commented disassembly of Bank C2 which I put to use by calling
	  one of Square's helper functions
	- Master ZED for general advice and discovering one of the Rage listing
	  routines awhile back.

-----------------------------------------------------------------

Final Fantasy 3 copyright 1994 Squaresoft.
This readme and all other files in the archive (as listed above)
  copyright 2003-2004 Assassin.
All rights reserved.
