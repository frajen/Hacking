#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#define null 0xffffffff
typedef unsigned char  byte;
typedef unsigned short word;
typedef unsigned long  ulong;
